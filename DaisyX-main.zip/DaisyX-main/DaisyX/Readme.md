# Clients
## Importing Aiogram
```python3
from DaisyX import bot
```

## Importing Pyrogram
```python3
from DaisyX.services.pyrogram import pbot
```
## Importing Telethon
```python3
from DaisyX.services.telethon import tbot
```
## Importing Userbot
```python3
from DaisyX.services.telethonuserbot import ubot
```

# DB
## Importing MongoDB
```python3
from DaisyX.services.mongo import mongodb
```
