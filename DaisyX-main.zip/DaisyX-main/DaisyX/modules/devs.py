# Credits Telegram @ChankitSaini

__mod_name__ = "Devs"
__help__ = """
<b>⚠️ Notice:</b>
Commands listed here only work for users with special access are mainly used for troubleshooting, debugging purposes.
Group admins/group owners do not need these commands. 

<b>Commands:</b> 

<b>Bot Owner Only: </b>
- <code>/leavechat chat id</code> : Leaves the chat
- <code>/ip</code> : Fetch server's ip (Works in pm only)
- <code>/term</code> : Runs the shell commands
- <code>/sbroadcast</code> : Smart broadcast in chats where bot is currently added.
- <code>/stopsbroadcast</code> : Stops the current ongoing broadcast
- <code>/continuebroadcast</code> : Continue the stopped broadcast
- <code>/purgecache</code> : Clear cache in redis server

<b>System Commands</b>
- <code>/botstop</code> : Shutdowns the bot.
- <code>/restart</code> : Restarts the bot
- <code>/upgrade</code> : Updates the bot.
- <code>/upload</code> : Uploads the file from bot's server
- <code>/crash</code> : Crashes the bot
- <code>/update</code> : updates the bot

<b>Operators:</b> 
- <code>/stats</code> : To get bot's current stats
- <code>/allcommands</code> : Shows the list of all available commands 
- <code>/allcmdsaliases</code> : Shows the aliases list 
- <code>/loadedmodules</code> : Shows the currently loaded modules
- <code>/avaiblebtns</code> : Shows the list of all message inline buttons
- <code>/logs</code> : Uploads the bot logs as file
- <code>/event</code> : To get a event via aiogram

"""
